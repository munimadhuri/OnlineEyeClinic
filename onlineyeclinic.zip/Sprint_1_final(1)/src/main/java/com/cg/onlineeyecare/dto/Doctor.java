package com.cg.onlineeyecare.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.cg.onlineeyecare.dto.TestModule;

/************************************************************************************
 * @author        K.Muni Madhuri 
 * Description    It is a entity class that provides the details of the doctor 
 * Version        1.0 
 * Created Date   22-MARCH-2021
 ************************************************************************************/

@Entity
public class Doctor {
	@Id
	public Integer doctorId;
	private String doctorName;
	private String doctorConsultationTime;
	private long doctorMobile;
	private String doctorEmail;
	private String doctorUsername;
	private String doctorPassword;
	private String doctorAddress;
	@OneToMany(cascade = CascadeType.ALL) 
	@JoinColumn(name = "doctorId")
	public List<TestModule> tests;


	/************************************************************************************
	 * Method:         getDoctorId 
	 * Description:    It is used to get the doctor Id by getter method.
	 * returns Integer:It returns doctor Id. 
	 * Created By -    K.Muni Madhuri
	 * Created Date -  22-MARCH-2021
	 * 
	 ************************************************************************************/

	public Integer getDoctorId() {
		return doctorId;
	}



	/************************************************************************************
	 * Method:           setDoctorId 
	 * Description:      It is used to set the doctor Id by setter method.
	 * @param doctorId:  doctor's Id. 
	 * Created By -      K.Muni Madhuri 
	 * Created Date -    22-MARCH-2021
	 * 
	 ************************************************************************************/

	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}

	/************************************************************************************
	 * Method:         getDoctorName 
	 * Description:    It is used to get the Dcotor Name by getter method. 
	 * returns String: It returns doctor Name. 
	 * Created By -    K.Muni Madhuri 
	 * Created Date -  22-MARCH-2021
	 * 
	 ************************************************************************************/

	public String getDoctorName() {
		return doctorName;
	}


	/************************************************************************************
	 * Method:             setDoctorName 
	 * Description:        It is used to set the Doctor Name by setter method.
	 * @param doctorName:  doctor's Name. 
	 * Created By -        K.Muni Madhuri 
	 * Created Date -      22-MARCH-2021
	 * 
	 ************************************************************************************/

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	/************************************************************************************
	 * Method:           getDoctorConsultationTime 
	 * Description:      It is used to get the DoctorConsultationTime by getter method. 
	 * returns String:   It returns DoctorConsultationTime. 
	 * Created By -      K.Muni Madhuri 
	 * Created Date -    22-MARCH-2021
	 * 
	 ************************************************************************************/

	public String getDoctorConsultationTime() {
		return doctorConsultationTime;
	}

	/************************************************************************************
	 * Method:                  setDoctorConsultationTime. 
	 * Description:             It is used to set the DoctorConsultationTime by setter method.
	 * @param DoctorConsultationTime: Doctor's Consultation Time. 
	 * Created By -             K.Muni Madhuri 
	 * Created Date -           22-MARCH-2021
	 * 
	 ************************************************************************************/
	public void setDoctorConsultationTime(String doctorConsultationTime) {
		this.doctorConsultationTime = doctorConsultationTime;
	}

	/************************************************************************************
	 * Method:              getDoctorMobile 
	 * Description:         It is used to get the Doctor Mobile by getter method.
	 * @param doctorMobile: doctor's Mobile. 
	 * Created By -         K.Muni Madhuri 
	 * Created Date -       22-MARCH-2021
	 * 
	 ************************************************************************************/

	public long getDoctorMobile() {
		return doctorMobile;
	}

	/************************************************************************************
	 * Method:              setDoctorMobile 
	 * Description:         It is used to set the doctor Mobile by setter method.
	 * @param doctorMobile: doctor's Mobile. 
	 * Created By -         K.Muni Madhuri 
	 * Created Date -       22-MARCH-2021
	 * 
	 ************************************************************************************/

	public void setDoctorMobile(long doctorMobile) {
		this.doctorMobile = doctorMobile;
	}

	/************************************************************************************
	 * Method:           getDoctorEmail 
	 * Description:      It is used to get the doctor Email by getter method. 
	 * returns String:   It returns doctor Email.
	 * Created By -      K.Muni Madhuri 
	 * Created Date -    22-MARCH-2021
	 * 
	 ************************************************************************************/

	public String getDoctorEmail() {
		return doctorEmail;
	}

	/************************************************************************************
	 * Method:                 setDoctorEmail 
	 * Description:            It is used to set the doctor Email by setter method.
	 * @param doctorEmail:     doctor's Email. 
	 * Created By -            K.Muni Madhuri 
	 * Created Date-           22-MARCH-2021
	 * 
	 ************************************************************************************/

	public void setDoctorEmail(String doctorEmail) {
		this.doctorEmail = doctorEmail;
	}

	/************************************************************************************
	 * Method:           getDoctorUsername 
	 * Description:      It is used to get the doctor userName by getter method.
	 * returns String:   It returns doctor userName.
	 * Created By -      K.Muni Madhuri
	 * Created Date -    22-MARCH-2021
	 * 
	 ************************************************************************************/

	public String getDoctorUsername() {
		return doctorUsername;
	}

	/************************************************************************************
	 * Method:            setDoctorUserName 
	 * Description:       It is used to set the Doctor userName by setter method. 
	 * returns String:    It returns patient userName. 
	 * Created By-        K.Muni Madhuri
	 *  Created Date -    22-MARCH-2021
	 * 
	 ************************************************************************************/

	public void setDoctorUsername(String doctorUsername) {
		this.doctorUsername = doctorUsername;
	}

	/************************************************************************************
	 * Method:           getDoctorPassword 
	 * Description:      It is used to get the doctor password by getter method.
	 * returns String:   It returns doctor password. 
	 * Created By -      K.Muni Madhuri 
	 * Created Date -    22-MARCH-2021
	 * 
	 ************************************************************************************/

	public String getDoctorPassword() {
		return doctorPassword;
	}

	/************************************************************************************
	 * Method:           setDoctorPassword 
	 * Description:      It is used to set the doctor password by setter method. 
	 * returns String:   It returns doctor password. 
	 * Created By -      K.Muni Madhuri 
	 * Created Date -    22-MARCH-2021
	 * 
	 ************************************************************************************/

	public void setDoctorPassword(String doctorPassword) {
		this.doctorPassword = doctorPassword;
	}

	/************************************************************************************
	 * Method:          getDoctorAddress 
	 * Description:     It is used to get the Doctor Address by getter method. 
	 * returns String:  It returns doctor Address.
	 * Created By -     K.Muni Madhuri
	 * Created Date -   22-MARCH-2021
	 * 
	 ************************************************************************************/
	public String getDoctorAddress() {
		return doctorAddress;
	}

	/************************************************************************************
	 * Method:        setDoctorAddress 
	 * Description:   It is used to set the doctor Address by setter method.
	 * returns String:It returns doctor Address.
	 * Created By -   K.Muni Madhuri 
	 * Created Date - 22-MARCH-2021
	 * 
	 ************************************************************************************/

	public void setDoctorAddress(String doctorAddress) {
		this.doctorAddress = doctorAddress;
	}


	/************************************************************************************
	 * Method:        Doctor 
	 * Description:   It is used to initialize the empty constructor.
	 * Created By -   K.Muni Madhuri 
	 * Created Date - 22-MARCH-2021
	 * 
	 ************************************************************************************/

	public Doctor() {
		super();
	}
	
	/************************************************************************************
	 * Method: Doctor Description: It is used to initialize the parameterized
	 * constructor.
	 * 
	 * @param doctorId:               doctor's Id.
	 * @param doctorName:             doctor's Name.
	 * @param doctorConsultationTime: doctor's consultation time.
	 * @param doctorMobile:           doctor's Mobile.
	 * @param doctorEmail:            doctor's Email.
	 * @param doctorUsername:         doctor's Username
	 * @param doctorPassword:         doctor's Password
	 * @param doctorAddress:          doctor's Address Created By - K.Muni Madhuri
	 *                                Created Date - 22-MARCH-2021
	 * 
	 ************************************************************************************/


	public Doctor(Integer doctorId, String doctorName, String doctorConsultationTime, long doctorMobile,
			String doctorEmail, String doctorUsername, String doctorPassword, String doctorAddress, List<TestModule> tests) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorConsultationTime = doctorConsultationTime;
		this.doctorMobile = doctorMobile;
		this.doctorEmail = doctorEmail;
		this.doctorUsername = doctorUsername;
		this.doctorPassword = doctorPassword;
		this.doctorAddress = doctorAddress;
		this.tests = tests;
	}




}
