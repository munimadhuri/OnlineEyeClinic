package com.cg.onlineeyecare.service;

import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlineeyecare.dao.IUserRepository;
import com.cg.onlineeyecare.dto.User;
import com.cg.onlineeyecare.exceptions.PasswordNotMatchException;
import com.cg.onlineeyecare.exceptions.UserNotFoundException;
/**********************************************************************************
 * @author                 P.saiteja reddy
 * Description             It is a user service implementation class that defines the methods
 *                         mentioned in its interface.
 * Version                 1.0
 * created date            24-03-2021
 *
 ****************************************************************************************/
@Service
public class IUserServiceImpl implements IUserService {
	@Autowired
	private IUserRepository userRepository;
	/************************************************************************************
	 * Method                     signIn
	 * Description                It is used to sign In into application
	 * @param user                user's reference variable
	 * @UserNotFoundException     It is raised due to invalid user details
	 * created by                 P.saiteja reddy
	 * created date               24-03-2021
	 ***********************************************************************************/

	@Override
	public Boolean signIn(User user) throws UserNotFoundException {
		Boolean status= false;
//		Optional<User> resultUser= userRepository.findById(user.getUserId());
		Optional<User> resultUser=userRepository.findByuserName(user.getUserName());
		if (resultUser.isPresent()) {
			if((resultUser.get().getPassword().equals(user.getPassword()))) 
			{
				status=true;

		} 
			else 
			
			throw new UserNotFoundException("User Not Found");
		}
		return status;
	}
	/*******************************************************************
	 * Method                                     signOut
	 * Description                                It is used to signout from application
	 * @param user                                user's reference variable
	 * @UserNotFoundException                     It raised due to invalid user details
	 * created by                                 P.saiteja reddy
	 * Created date                               24-03-2021
	 ***********************************************************************/

	@Override
	public Boolean  signOut(User user) throws UserNotFoundException {
		// TODO Auto-generated method stub
		Boolean status=false;
//		Optional<User> resultUser= userRepository.findById(user.getUserId());
		Optional<User> resultUser=userRepository.findByuserName(user.getUserName());

		if (!resultUser.isPresent()) {
			throw new UserNotFoundException("User Not Found");
		}
		else if(resultUser.get().getPassword().equals(user.getPassword())) {
			 status = true;
		}
		return status;
	}
	/******************************************************************************
	 * Method                                changePassword
	 * Description                           It is used to change the password
	 * @param user                           User's refernce variable
	 * @throws PasswordNotMatchException     It is raised due to invalid password
	 * @UserNotFoundException                It is raised due to invalid user details
	 * created by                            p.saiteja reddy
	 * created date                          24-03-2021
	 ********************************************************************************/

	@Override
	public User changePassword(String newPassword, User user) throws UserNotFoundException, PasswordNotMatchException {
		// TODO Auto-generated method stub
//		Optional<User> resultUser=userRepository.findById(id);
		Optional<User> resultUser=userRepository.findByuserName(user.getUserName());
		if(resultUser.isPresent()) {
			if((resultUser.get().getPassword().equals(user.getPassword())))
			{
				user.setPassword(newPassword);
				return userRepository.save(user);
			}
			else
			{
				throw new PasswordNotMatchException("Password Not matched please enter valid password");
			}
		}
		else
		{
			throw new UserNotFoundException("User Not Found");
		}	
	}

}
