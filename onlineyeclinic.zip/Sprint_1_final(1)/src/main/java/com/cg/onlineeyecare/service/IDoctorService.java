package com.cg.onlineeyecare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlineeyecare.dto.Appointment;
import com.cg.onlineeyecare.dto.Doctor;
import com.cg.onlineeyecare.dto.TestModule;
import com.cg.onlineeyecare.exceptions.DoctorIdNotFoundException;


/************************************************************************************
 *          @author          K.Muni Madhuri
 *          Description      It is a Doctor service interface that describes the abstract methods
 *                           used in its implementation class.
  *         Version             1.0
  *         Created Date     22-MARCH-2021
 ************************************************************************************/

public interface IDoctorService {


	
	Doctor addDoctor(Doctor doctor);

	
	public Doctor viewDoctor(int doctorId)throws DoctorIdNotFoundException;

	public List<Doctor> viewDoctorsList();
	public TestModule createTest(TestModule test);
	public Doctor updateDoctor(Doctor doctor) throws DoctorIdNotFoundException;
	Doctor deleteDoctor(int doctorId) throws DoctorIdNotFoundException;
	List<Appointment> viewAllAppointments();
}
