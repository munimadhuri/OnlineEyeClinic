package com.cg.onlineeyecare.dto;

import java.time.LocalDate;

import java.time.LocalTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
/************************************************************************************
 *@author          K NAGA VAISHNAVI
 *Description      It is a entity class that provides the details of the appointment 
 *Version             1.0
 *Created Date     22-MARCH-2021
 ************************************************************************************/

@Entity
public class Appointment {
@Id
private Integer appointmentId;
@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
private LocalDate dateOfAppointment;
@JsonFormat (shape = JsonFormat.Shape.STRING,pattern="hh:mm:ss a")
LocalTime timeOfAppointment;
Double consultationFee;
@ManyToOne(cascade=CascadeType.MERGE)
@JoinColumn(name="doctor_Id")
Doctor doctor_Id;
@ManyToOne(cascade=CascadeType.MERGE)
@JoinColumn(name="patient_Id")
@JsonIgnore
Patient patient_Id;
/**
 * @param appointmentId 
 * @param dateOfAppointment
 * @param timeOfAppointment 
 * @param consultationFee 
 * 
 */
/************************************************************************************
 * Method:                          Appointment
 *Description:                      It is used to initialize the empty constructor.
 *Created By                      - K NAGA VAISHNAVI
 *Created Date                    - 22-MARCH-2021                           
 
 ************************************************************************************/
public Appointment() {
	super();
}
/************************************************************************************
 * Method:                          Appointment
 *Description:                      It is used to initialize the parameterized constructor.
 *@param apppointmentId:            apppointment's Id. 
 *@param dateOfAppointment:         date of appointment. 
 *@param timeOfAppointment:         time Of Appointment.       
 *@param consultantFee:             fee for consulting.  
 *Created By                       - K NAGA VAISHNAVI
 *Created Date                     - 22-MARCH-2021                           
 
 ************************************************************************************/

/************************************************************************************
 * Method:                          getAppointmentId
 *Description:                      It is used to get the appointment Id by getter method.
 *returns Integer:                  It returns appointment Id.
 *Created By                      - K NAGA VAISHNAVI
 *Created Date                    - 22-MARCH-2021                           
 
 ************************************************************************************/
public Integer getAppointmentId() {
	return appointmentId;
}
public Appointment(Integer appointmentId, LocalDate dateOfAppointment, LocalTime timeOfAppointment,
		Double consultationFee, Doctor doctorId, Patient patientId) {
	super();
	this.appointmentId = appointmentId;
	this.dateOfAppointment = dateOfAppointment;
	this.timeOfAppointment = timeOfAppointment;
	this.consultationFee = consultationFee;
	this.doctor_Id = doctorId;
	this.patient_Id = patientId;
}
/************************************************************************************
 * Method:                          setAppointmentId
 *Description:                      It is used to set the appointment Id by setter method.
 * @param appointmentId:            appointment's Id. 
 *Created By                      - K NAGA VAISHNAVI
 *Created Date                    - 22-MARCH-2021                           
 
 ************************************************************************************/
public void setAppointmentId(Integer appointmentId) {
	this.appointmentId = appointmentId;
}
/************************************************************************************
 * Method:                          getDateOfAppointment
 *Description:                      It is used to get the appointment date by getter method.
 *returns String:                   It returns appointment date.
 *@param dateOfAppointment          appointment's date.
 *@JsonFormat                       is used to specify format pattern for Date field.
 *Created By                      - K NAGA VAISHNAVI
 *Created Date                    - 22-MARCH-2021                           
 
 ************************************************************************************/
@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
public LocalDate getDateOfAppointment() {
	return dateOfAppointment;
}
/************************************************************************************
 * Method:                          setDateOfAppointment
 *Description:                      It is used to set the appointment date by setter method.
 * @param dateOfAppointmentId:      appointment's date. 
 *Created By                      - K NAGA VAISHNAVI
 *Created Date                    - 22-MARCH-2021                           
 
 ************************************************************************************/
public void setDateOfAppointment(LocalDate dateOfAppointment) {
	this.dateOfAppointment = dateOfAppointment;
}
/************************************************************************************
 * Method:                          getTimeOfAppointment
 *Description:                      It is used to get the appointment time by getter method.
 *returns String:                   It returns appointment time.
 *@JsonFormat                       is used to specify format pattern for time field.
 *Created By                      - K NAGA VAISHNAVI
 *Created Date                    - 22-MARCH-2021                           
 
 ************************************************************************************/
@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "hh:mm:ss a")
public LocalTime getTimeOfAppointment() {
	return timeOfAppointment;
}
/************************************************************************************
 * Method:                          setTimeOfAppointment
 *Description:                      It is used to set the appointment time by setter method.
 * @param timeOfAppointment:        appointment's time. 
 *Created By                      - K NAGA VAISHNAVI
 *Created Date                    - 22-MARCH-2021                           
 
 ************************************************************************************/
public void setTimeOfAppointment(LocalTime timeOfAppointment) {
	this.timeOfAppointment = timeOfAppointment;
}
/************************************************************************************
 * Method:                          getConsultantFee
 *Description:                      It is used to get the consultant fee  by getter method.
 *returns Double:                  It returns consultant fee.
 *Created By                      - K NAGA VAISHNAVI
 *Created Date                    - 22-MARCH-2021                           
 
 ************************************************************************************/
public Double getConsultantFee() {
	return consultationFee;
}
/************************************************************************************
 * Method:                          setConsultantFee
 *Description:                      It is used to set the consultant fee by setter method.
 *returns Double:                  It returns consultant fee.
 *Created By                      - K NAGA VAISHNAVI
 *Created Date                    - 22-MARCH-2021                           
 
 ************************************************************************************/
public void setConsultantFee(Double consultantFee) {
	this.consultationFee = consultantFee;
}
public Doctor getDoctorId() {
	return doctor_Id;
}
public void setDoctorId(Doctor doctorId) {
	this.doctor_Id = doctorId;
}
public Patient getPatientId() {
	return patient_Id;
}
public void setPatientId(Patient patientId) {
	this.patient_Id = patientId;
}

@Override
public String toString() {
	return "Appointment [appointmentId=" + appointmentId + ", dateOfAppointment=" + dateOfAppointment
			+ ", timeOfAppointment=" + timeOfAppointment + ", consultationFee=" + consultationFee + ", doctorId="
			+ doctor_Id + ", patientId=" + patient_Id + "]";
}



}
