package com.cg.onlineeyecare.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.onlineeyecare.dto.Appointment;
import com.cg.onlineeyecare.dto.Patient;
import com.cg.onlineeyecare.dto.Report;
import com.cg.onlineeyecare.exceptions.AppointmentIdNotFoundException;
import com.cg.onlineeyecare.exceptions.PatientIdFoundNotException;
/************************************************************************************
 *          @author          Rushitha
 *          Description      It is a patient service interface that describes the abstract methods
 *                           used in its implementation class.
  *         Version             1.0
  *         Created Date     25-MARCH-2021
 ************************************************************************************/
@Service
public interface PatientService {

	Patient addPatient(Patient tempPatient);
	Patient updatePatient(Patient patient);
	Patient deletePatient(int patientId)throws PatientIdFoundNotException;
	List<Patient> viewPatientList();
	Patient viewPatient(int patientId)throws PatientIdFoundNotException;
	Appointment bookAppointment(Appointment appointment);
	Appointment viewAppointmentDetail(int appointmentid)throws AppointmentIdNotFoundException;
	Report viewReport(int patientId)throws PatientIdFoundNotException;
	
}
