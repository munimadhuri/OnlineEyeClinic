package com.cg.onlineeyecare.dto;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.stereotype.Component;
import com.fasterxml.jackson.annotation.JsonFormat;
/************************************************************************************
 *          @author          Rushitha
 *          Description      It is a entity class for Patients default constructor, parameterized
 *                           constructor along with getters and setters 
  *         Version             1.0
  *         Created Date    25-March-2020
 ************************************************************************************/
@Entity
public class Patient {
	/**
	 * 
	 */
@Id
	private int patientId;
	private String patientName;
	private int patientAge;
	private long patientMobile;
	private String patientEmail;
	@JsonFormat(pattern="dd-MM-yyyy")
	private LocalDate patientDOB;
	private String patientUserName;
	private String patientPassword;
	private String address;
	/************************************************************************************
	 * Method:                          patient
     *Description:                      It is used to initialize the empty constructor.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	@OneToMany(mappedBy="patient_Id")
	private List<Appointment> appointment;
	/**
	 * 
	 */
	public Patient() {
		super();
	}

	/************************************************************************************
	 * Method:                          patient
     *Description:                      It is used to initialize the parameterized constructor.
     *@param testId:                  
	 * @param patientId
	 * @param patientName
	 * @param patientAge
	 * @param patientMobile
	 * @param patientEmail
	 * @param patientDOB
	 * @param patientUserName
	 * @param patientPassword
	 * @param address
	 ************************************************************************************/
	public Patient(int patientId, String patientName, int patientAge, long patientMobile, String patientEmail,
			LocalDate patientDOB, String patientUserName, String patientPassword, String address) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.patientAge = patientAge;
		this.patientMobile = patientMobile;
		this.patientEmail = patientEmail;
		this.patientDOB = patientDOB;
		this.patientUserName = patientUserName;
		this.patientPassword = patientPassword;
		this.address = address;
	}
	/************************************************************************************
	 * Method:                          getPatientId
     *Description:                      It is used to get the patient Id by getter method.
     *returns Integer:                  It returns patient Id.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public int getPatientId() {
		return patientId;
	}
	/************************************************************************************
	 * Method:                          setPatientId
     *Description:                      It is used to set the patient Id by setter method.
     * @param patientId:                   patient's Id. 
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	/************************************************************************************
	 * Method:                          getPatientName
    *Description:                      It is used to get the patient Name by getter method.
    *returns String:                   It returns patient Name.
    *Created By                      - Rushitha
    *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public String getPatientName() {
		return patientName;
	}
	/************************************************************************************
	 * Method:                          setPatientName
     *Description:                      It is used to set the patient Name by setter method.
     * @param patientName:                 patient's Name. 
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	/************************************************************************************
	 * Method:                          getPatientAge
     *Description:                      It is used to get the patient Age by getter method.
     * @param patientAge:                   patient's Age. 
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public int getPatientAge() {
		return patientAge;
	}
	/************************************************************************************
	 * Method:                          setPatientId
     *Description:                      It is used to set the patient Age by setter method.
     * @param patientAge:                   patient's Age. 
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public void setPatientAge(int patientAge) {
		this.patientAge = patientAge;
	}
	/************************************************************************************
	 * Method:                          getPatientMobile
     *Description:                      It is used to get the patient Mobile by getter method.
     * @param patientMobile:                   patient's Mobile. 
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public long getPatientMobile() {
		return patientMobile;
	}
	/************************************************************************************
	 * Method:                          setPatientMobile
     *Description:                      It is used to set the patient Mobile by setter method.
     * @param patientMobile:                   patient's Mobile. 
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public void setPatientMobile(long patientMobile) {
		this.patientMobile = patientMobile;
	}
	/************************************************************************************
	 * Method:                          getPatientEmail
     *Description:                      It is used to get the patient Email  by getter method.
     *returns String:                   It returns patient Email.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public String  getPatientEmail() {
		return patientEmail;
	}
	/************************************************************************************
	 * Method:                          setPatientEmail
     *Description:                      It is used to set the patient Email by setter method.
     *returns String:                   It returns patient Email.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public void setPatientEmail(String patientEmail) {
		this.patientEmail = patientEmail;
	}
	/************************************************************************************
	 * Method:                          getPatientDOB
     *Description:                      It is used to get the patientDOB by getter method.
     *returns Integer:                  It returns patient DOB.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public LocalDate getPatientDOB() {
		return patientDOB;
	}
	/************************************************************************************
	 * Method:                          getPatientDOB
     *Description:                      It is used to set the patient DOB by setter method.
     *returns Integer:                  It returns patient DBO.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public void setPatientDOB(LocalDate patientDOB) {
		this.patientDOB = patientDOB;
	}
	/************************************************************************************
	 * Method:                          getPatientUserName
     *Description:                      It is used to get the patient userName by getter method.
     *returns String:                   It returns patient userName.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public String getPatientUserName() {
		return patientUserName;
	}
	/************************************************************************************
	 * Method:                          setPatientUserName
     *Description:                      It is used to set the patient userName by setter method.
     *returns String:                   It returns patient userName.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public void setPatientUserName(String patientUserName) {
		this.patientUserName = patientUserName;
	}
	/************************************************************************************
	 * Method:                          getPatientPassword
     *Description:                      It is used to get the patient password by getter method.
     *returns String:                   It returns patient password.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public String getPatientPassword() {
		return patientPassword;
	}
	/************************************************************************************
	 * Method:                          setPatientPassword
     *Description:                      It is used to set the patient password by setter method.
     *returns String:                   It returns patient password.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public void setPatientPassword(String patientPassword) {
		this.patientPassword = patientPassword;
	}
	/************************************************************************************
	 * Method:                          getAddress
     *Description:                      It is used to get the Address by getter method.
     *returns String:                   It returns patient Address.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public String getAddress() {
		return address;
	}
	/************************************************************************************
	 * Method:                          setAddress
     *Description:                      It is used to set the patient Address by setter method.
     *returns String:                   It returns Patient Address.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ************************************************************************************/
	public void setAddress(String address) {
		this.address = address;
	}


	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", patientName=" + patientName + ", patientAge=" + patientAge
				+ ", patientMobile=" + patientMobile + ", patientEmail=" + patientEmail + ", patientDOB=" + patientDOB
				+ ", patientUserName=" + patientUserName + ", patientPassword=" + patientPassword + ", address="
				+ address + "]";
	}

	public Patient get(int i) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
