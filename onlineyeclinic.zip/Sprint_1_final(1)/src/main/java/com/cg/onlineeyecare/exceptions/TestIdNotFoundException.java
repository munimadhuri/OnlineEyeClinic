package com.cg.onlineeyecare.exceptions;

public class TestIdNotFoundException extends Exception {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
public TestIdNotFoundException() {
	// TODO Auto-generated constructor stub
}
public TestIdNotFoundException(String message) {
	super(message);
}
}
