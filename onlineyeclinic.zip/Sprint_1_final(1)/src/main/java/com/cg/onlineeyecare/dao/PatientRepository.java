package com.cg.onlineeyecare.dao;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.cg.onlineeyecare.dto.Patient;
import com.cg.onlineeyecare.dto.Report;
import com.cg.onlineeyecare.exceptions.AppointmentIdNotFoundException;
import com.cg.onlineeyecare.exceptions.PatientIdFoundNotException;
import com.sun.el.stream.Optional;
/************************************************************************************
 *          @author          Rushitha
 *          Description      It is a patient repository interface that extends jpa repository 
 *                           that contains inbuilt methods for various operations
  *         Version             1.0
  *         Created Date      25-MARCH-2021
 ************************************************************************************/
@Repository
public interface PatientRepository extends JpaRepository<Patient,Integer>  {
	@Query("SELECT Rep FROM Report Rep where Rep.patientId=?1")
	Report viewReport(Integer patient_id);
}


		