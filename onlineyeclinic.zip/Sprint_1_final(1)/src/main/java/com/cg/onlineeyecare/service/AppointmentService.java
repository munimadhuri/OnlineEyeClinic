package com.cg.onlineeyecare.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.onlineeyecare.dto.Appointment;
import com.cg.onlineeyecare.exceptions.*;
/************************************************************************************
 *          @author          K NAGA VAISHNAVI
 *          Description      It is a test service interface that describes the abstract methods
 *                           used in its implementation class.
  *         Version             1.0
  *         Created Date     22-MARCH-2021
 ************************************************************************************/
public interface AppointmentService {
	Appointment bookAppointment(Appointment appointment);

	Appointment updateAppointment(Appointment appointment) throws InvalidAppointmentException;

	Appointment cancelAppointment(int appointmentId) throws AppointmentIdNotFoundException;

	Appointment viewAppointment(int appointmentId) throws AppointmentIdNotFoundException;

	List<Appointment> viewAllAppointments();

	List<Appointment> viewAppointments(LocalDate date);
}
