package com.cg.onlineeyecare.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.onlineeyecare.dto.Doctor;
import com.cg.onlineeyecare.dto.TestModule;
import com.cg.onlineeyecare.exceptions.DoctorIdNotFoundException;
import com.cg.onlineeyecare.exceptions.PasswordNotMatchException;
import com.cg.onlineeyecare.exceptions.TestIdNotFoundException;
import com.cg.onlineeyecare.exceptions.UserNotFoundException;
import com.cg.onlineeyecare.service.IDoctorServiceImpl;
@SpringBootTest
class IDoctorServiceTest {
	@Autowired
	IDoctorServiceImpl iDoctorService;
	@Autowired
	AppointmentService appointmentservice;
	
	/***********************************************************
	 * Method                                         addDoctor
	 * Description                                    It is used to test whether the doctor is added or not		
	 * @throws DoctorIdNotFoundException              It is raises due to invalid doctor details
	 * created by                                     K.MUni Madhuri
	 * created date                                   25-03-2021
	   ***********************************************************/
	
	
	@Test
	void addDoctor() throws DoctorIdNotFoundException {
		Doctor doc1=new Doctor(111,"Madhuri","10am",98989898,"madhuri@gmail.com","madhuri","madhuri","chennai", null);
		assertEquals("Madhuri", iDoctorService.addDoctor(doc1).getDoctorName());
	}
	
	/***********************************************************
	 * Method                                         updateDoctor
	 * Description                                    It is used to test whether the doctor is updated or not		
	 * @throws DoctorIdNotFoundException              It is raises due to invalid doctor details
	 * created by                                     K.MUni Madhuri
	 * created date                                   25-03-2021
	   ***********************************************************/
	
	@Test
	void updateDoctor() throws DoctorIdNotFoundException {
		Doctor test1 = new Doctor(111,"Madhuri","10:30am",989898,"madhuri@gmail.com","madhuri","madhuri","chennai", null);
		assertEquals("Madhuri", iDoctorService.updateDoctor(test1).getDoctorName());
	}
	
	/***********************************************************
	 * Method                                         viewDoctorsList
	 * Description                                    It is used to test whether the doctor details matches with given DoctorId	
	 * created by                                     K.MUni Madhuri
	 * created date                                   25-03-2021
	   ***********************************************************/
	
	@Test
	void viewDoctorsList() {
		assertEquals(1, iDoctorService.viewDoctorsList().get(0).getDoctorId());
	}
	
	/***********************************************************
	 * Method                                         viewDoctor
	 * Description                                    It is used to test whether the doctor ConsultationTime matches with the given time		
	 * created by                                     K.MUni Madhuri
	 * created date                                   25-03-2021
	   ***********************************************************/
	
	@Test
	void viewDoctor() throws DoctorIdNotFoundException {
		assertEquals("10am", iDoctorService.viewDoctor(1).getDoctorConsultationTime());
	}
	
	/***********************************************************
	 * Method                                         deleteDoctor
	 * Description                                    It is used to test whether the doctor with the given id is deleted or not		
	 * created by                                     K.MUni Madhuri
	 * created date                                   25-03-2021
	   ***********************************************************/
	
	
	@Test
	void deleteDoctor() throws DoctorIdNotFoundException
	{
		assertEquals(111, iDoctorService.deleteDoctor(111).getDoctorId());
	}
	
	/***********************************************************
	 * Method                                         createTest
	 * Description                                    It is used to test whether the given test is created or not		
	 * created by                                     K.MUni Madhuri
	 * created date                                   25-03-2021
	   ***********************************************************/
   
	@Test
	void createTest() throws TestIdNotFoundException {
		TestModule test2 = new TestModule(50, "Normal eye checkup", "Eye checkup", "checkup", 500);
		assertEquals(50, iDoctorService.createTest(test2).getTestId());
	}
	
	/***********************************************************
	 * Method                                         viewAllAppointments
	 * Description                                    It is used to test whether the appointment details matches with the given appointmentId		
	 * created by                                     K.MUni Madhuri
	 * created date                                   25-03-2021
	   ***********************************************************/
	
	@Test
	void viewAllAppointments()
	{
		assertEquals(1,appointmentservice.viewAllAppointments().get(0).getAppointmentId());
	}

      
}